import React, { Component } from "react";

class Home extends Component {
  render() {
    return (
      <div>
        <h2>Home Page</h2>
        <h3> You can see User's here.</h3>
      </div>
    );
  }
}

export default Home;
