import React, { Component } from "react";
import { Link } from "react-router-dom";
class UserOne extends Component {
  render() {
    return (
      <div>
        <h2> Hello</h2>
        <h2>I am user number one...</h2>
        <h3> You can see my post here.</h3>
        <br />
        <Link to="/">Go Home</Link>
      </div>
    );
  }
}

export default UserOne;
