import React, { Component } from "react";
import { Link } from "react-router-dom";

class UserTwo extends Component {
  render() {
    return (
      <div>
        <h2> Hello</h2>
        <h2>I am user number Two...</h2>
        <h3> You can see my post here.</h3>
        <br />
        <Link to="/">Go Home</Link>
      </div>
    );
  }
}

export default UserTwo;
