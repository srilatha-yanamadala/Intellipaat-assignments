import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import UserTwo from "./components/User-2";
import UserOne from "./components/User-1";
import Home from "./components/Home";
import NotFound from "./components/NotFound";
import Hello from "./components/Unknown";

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <h2>Welcome to Homepage</h2>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <ul className="navbar-nav mr-auto">
              <li>
                <Link to={"/"} className="nav-link">
                  {" "}
                  Home{" "}
                </Link>
              </li>
              <li>
                <Link to={"/UserOne"} className="nav-link">
                  UserOne
                </Link>
              </li>
              <li>
                <Link to={"/UserTwo"} className="nav-link">
                  UserTwo
                </Link>
              </li>
              <li>
                <Link to={"/Hello"} className="nav-link">
                  Hello
                </Link>
              </li>
              <li>
                <Link to={"/NotFound"} className="nav-link">
                  Broken
                </Link>
              </li>
            </ul>
          </nav>
          <hr />
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/UserOne" component={UserOne} />
            <Route path="/UserTwo" component={UserTwo} />
            <Route path="/Hello" component={Hello} />
            <Route path="/NotFound" component={NotFound} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
