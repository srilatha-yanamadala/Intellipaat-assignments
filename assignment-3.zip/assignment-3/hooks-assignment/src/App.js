import React, { useState, useEffect } from "react";
function App() {
  const DocumentTitle = () => {
    const [title, setTitle] = useState({ firstTitle: "", lastTitle: "" });
    useEffect(() => {
      // Update the document title using the browser API
      document.title =
        "your title is " + title.firstTitle + " " + title.lastTitle;
    });
    return (
      <form>
        <input
          type="text"
          value={title.firstTitle}
          onChange={(e) => setTitle({ ...title, firstTitle: e.target.value })}
        />
        <input
          type="text"
          value={title.lastTitle}
          onChange={(e) => setTitle({ ...title, lastTitle: e.target.value })}
        />
        <h2>Your First Title - {title.firstTitle}</h2>
        <h2>Your Last Title - {title.lastTitle}</h2>
      </form>
    );
  };

  return (
    <div className="App">
      <DocumentTitle />
    </div>
  );
}

export default App;
