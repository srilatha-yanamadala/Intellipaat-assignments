import { Component } from "react";
import ProductlistComponent from "./Product-list.comp"

class ProductComponent extends Component {

    render() {

        return <div style={{ border: "2px solid red", margin: "10px", padding: "10px" }}>
            <h1>Product Component</h1>
            <ProductlistComponent />
            <hr />




        </div>
    }
}
export default ProductComponent;