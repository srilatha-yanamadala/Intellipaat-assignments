import { Component } from "react";
import ProductComponent from "./Product.comp";


class CartComponent extends Component {
    render() {
        return <div style={{ border: "2px solid red", margin: "10px", padding: "10px" }}>
            <h1>Cart Component</h1>
            <hr />
            <ProductComponent />
        </div>
    }
}
export default CartComponent;