import { Component } from "react";
class ProductlistComponent extends Component {

    render() {
        const Products = [
            { id: "01", productname: "car", productprice: "2000" },
            { id: "01", productname: "phone", productprice: "4000" },
            { id: "02", productname: "bed", productprice: "200" },
            { id: "03", productname: "light", productprice: "300" },
            { id: "04", productname: "bus", productprice: "5000" }];
        const itemList = Products.map((item) => (
            <li>
                {item.productname}-{item.productprice}
                ......<button>Add</button>
            </li>
        ));

        return <div style={{ border: "2px solid red", margin: "10px", padding: "10px" }}>
            <h1>Product list Component</h1>
            <ol >{itemList} </ol>
            <hr />




        </div>
    }
}
export default ProductlistComponent;