import { Component } from "react";
class TotalPriceComponent extends Component {

    render() {
        const Products = [
            { id: "01", productname: "car", productprice: "2000" },
            { id: "01", productname: "phone", productprice: "4000" },
            { id: "02", productname: "bed", productprice: "200" },
            { id: "03", productname: "light", productprice: "300" },
            { id: "04", productname: "bus", productprice: "5000" }];
        const Total = Products.map((item) => (

            this.state.products.reduce(
                (sum, products) => sum + products.productprice,
                0
            )
        ));
        return <div style={{ border: "2px solid red", margin: "10px", padding: "10px" }}>
            <h1>Total price Component</h1>
            <h1> Total price : {Total} </h1>
            <hr />

        </div>
    }
}
export default TotalPriceComponent;