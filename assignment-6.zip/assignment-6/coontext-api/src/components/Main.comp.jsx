import { Component } from "react";
import CartComponent from "./Cart.comp";

class MainComponent extends Component {
    render() {
        return <div style={{ border: "2px solid red", margin: "10px", padding: "10px" }}>
            <h1>Main Component</h1>
            <hr />
            <CartComponent />
        </div>
    }
}
export default MainComponent;