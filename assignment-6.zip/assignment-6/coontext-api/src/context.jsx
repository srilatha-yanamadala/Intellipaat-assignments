import React from 'react';

const Context = React.createContext();

// export let FamilyProvider = FamilyContext.Provider;
// export let FamilyConsumer = FamilyContext.Consumer;

let Provider = Context.Provider;
let Consumer = Context.Consumer;

export { Consumer, Provider };