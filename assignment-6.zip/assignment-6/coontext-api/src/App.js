import MainComponent from "./components/Main.comp";

function App() {
  return (
    <div className="App">
      <MainComponent />
    </div>
  );
}

export default App;
